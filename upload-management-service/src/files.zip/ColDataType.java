package com.enterprise.upload.model.enums;

/**
 * Kiểu dữ liệu cột - ánh xạ từ PostgreSQL custom type {@code upload_db.col_data_type}.
 */
public enum ColDataType {
    STRING,
    INTEGER,
    BIGINT,
    DECIMAL,
    BOOLEAN,
    DATE,
    DATETIME,
    TIMESTAMP,
    EMAIL,
    PHONE,
    JSON,
    ARRAY,
    UUID,
    BASE64,
    XML_NODE
}
