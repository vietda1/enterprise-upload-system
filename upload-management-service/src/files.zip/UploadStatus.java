package com.enterprise.upload.model.enums;

/**
 * Trạng thái vòng đời của một Upload.
 *
 * <pre>
 * PENDING
 *   └─► UPLOADED
 *         └─► VALIDATED ──────────────────► PENDING_APPROVAL
 *         └─► VALIDATION_FAILED (terminal)       │
 *                                           ┌────┴────┐
 *                                        APPROVED   REJECTED (terminal)
 *                                           │
 *                                        INGESTING
 *                                           │
 *                                   ┌──────┴──────┐
 *                                COMPLETED       FAILED (terminal)
 * PENDING ──► EXPIRED (terminal)
 * </pre>
 */
public enum UploadStatus {
    PENDING,
    UPLOADED,
    VALIDATED,
    VALIDATION_FAILED,
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    INGESTING,
    COMPLETED,
    FAILED,
    EXPIRED,
    DELETED
}
