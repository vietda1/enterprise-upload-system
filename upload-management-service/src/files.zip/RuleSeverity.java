package com.enterprise.upload.model.enums;

/**
 * Mức độ nghiêm trọng của rule - ánh xạ từ PostgreSQL custom type {@code upload_db.rule_severity}.
 *
 * <ul>
 *   <li>{@link #BLOCKER}  – Dừng toàn bộ upload, không được ingest</li>
 *   <li>{@link #CRITICAL} – Row bị loại, tính vào invalid_rows</li>
 *   <li>{@link #WARNING}  – Ghi nhận nhưng vẫn ingest</li>
 *   <li>{@link #INFO}     – Chỉ log, không ảnh hưởng</li>
 * </ul>
 */
public enum RuleSeverity {
    BLOCKER,
    CRITICAL,
    WARNING,
    INFO
}
