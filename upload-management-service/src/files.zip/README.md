# Entity Models – Upload Management Service

## Cấu trúc package

```
com.enterprise.upload.model
├── base/
│   ├── BaseEntity.java          – created_at / updated_at (@PrePersist / @PreUpdate)
│   └── AuditableEntity.java     – extends BaseEntity + created_by / updated_by
│
├── enums/
│   ├── UploadStatus.java        – PENDING → UPLOADED → VALIDATED → ... → COMPLETED
│   ├── IngestionStatus.java     – PENDING | RUNNING | COMPLETED | FAILED | RETRYING | CANCELLED
│   ├── ValidationStatus.java    – PENDING | RUNNING | PASSED | FAILED | ERROR
│   ├── ValidationTableStatus.java – PENDING | RUNNING | PASSED | FAILED | SKIPPED | NOT_FOUND
│   ├── VirusScanStatus.java     – PENDING | RUNNING | CLEAN | INFECTED | ERROR
│   ├── ColDataType.java         – STRING | INTEGER | DECIMAL | DATE | EMAIL | BASE64 | ...
│   ├── RuleType.java            – NOT_NULL | REGEX_MATCH | FOREIGN_KEY | CROSS_TABLE_SUM | ...
│   ├── RuleSeverity.java        – BLOCKER | CRITICAL | WARNING | INFO
│   ├── WriteMode.java           – APPEND | UPSERT | REPLACE | MERGE | TRUNCATE
│   └── SharePermission.java     – READ | WRITE | DELETE
│
├── DatasetConfig.java           ← upload_db.dataset_configs
├── DatasetTable.java            ← upload_db.dataset_tables
├── TableColumn.java             ← upload_db.table_columns
├── TableValidationRule.java     ← upload_db.table_validation_rules
│
├── Upload.java                  ← upload_db.uploads               (main entity)
├── UploadEvent.java             ← upload_db.upload_events
├── UploadHistory.java           ← upload_db.upload_history
├── UploadMetadata.java          ← upload_db.upload_metadata        (composite PK)
├── UploadTag.java               ← upload_db.upload_tags
├── UploadShare.java             ← upload_db.upload_shares
│
├── IngestionJob.java            ← upload_db.ingestion_jobs
├── KafkaEventLog.java           ← upload_db.kafka_event_log
├── PresignedUrlLog.java         ← upload_db.presigned_url_logs
│
├── ValidationDatasetResult.java ← upload_db.validation_dataset_results
├── ValidationTableResult.java   ← upload_db.validation_table_results
└── ValidationRuleResult.java    ← upload_db.validation_rule_results
```

## Quan hệ giữa các entity

```
DatasetConfig (1) ──── (N) DatasetTable
DatasetTable  (1) ──── (N) TableColumn
DatasetTable  (1) ──── (N) TableValidationRule

Upload (1) ──── (N) UploadEvent
Upload (1) ──── (N) UploadHistory
Upload (1) ──── (N) UploadMetadata       [composite PK: upload_id + meta_key]
Upload (1) ──── (N) UploadTag
Upload (1) ──── (N) UploadShare
Upload (1) ──── (N) IngestionJob
Upload (1) ──── (N) ValidationDatasetResult

ValidationDatasetResult (1) ──── (N) ValidationTableResult
ValidationTableResult   (1) ──── (N) ValidationRuleResult

ValidationTableResult.datasetTable  → DatasetTable  (nullable)
ValidationRuleResult.validationRule → TableValidationRule (nullable, snapshot)
```

## Dependencies cần thêm vào pom.xml

```xml
<!-- Spring Data JPA -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>

<!-- Lombok -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <optional>true</optional>
</dependency>

<!-- PostgreSQL Driver -->
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>

<!-- Hypersistence Utils: JsonBinaryType (jsonb) + ListArrayType (text[]) -->
<dependency>
    <groupId>io.hypersistence</groupId>
    <artifactId>hypersistence-utils-hibernate-63</artifactId>
    <version>3.7.3</version>
</dependency>
```

## Lưu ý quan trọng

### 1. PostgreSQL custom ENUM types
Các cột dùng custom type (`upload_db.col_data_type`, `upload_db.rule_type_enum`,
`upload_db.rule_severity`) cần khai báo đúng `columnDefinition`:

```java
@Enumerated(EnumType.STRING)
@Column(name = "data_type", columnDefinition = "upload_db.col_data_type")
private ColDataType dataType;
```

Nếu dùng Flyway/Liquibase, đảm bảo migration tạo ENUM type trước khi tạo bảng.

### 2. PostgreSQL text[] array
Các cột `approval_roles`, `upsert_keys`, `ref_columns` lưu dạng `text[]`.
Cần annotation `@Type(ListArrayType.class)` từ hypersistence-utils.

```java
@Type(ListArrayType.class)
@Column(name = "approval_roles", columnDefinition = "text[]")
private List<String> approvalRoles;
```

### 3. DB Triggers trên bảng uploads
- `trg_uploads_updated_at`: tự update `updated_at` → **không** dùng `@PreUpdate` trên Upload
- `trg_log_upload_status_change`: tự ghi vào `upload_history` → không cần ghi thủ công

### 4. Upload – FK bằng upload_id (business key)
Các bảng `upload_events`, `upload_history`, `upload_metadata`, `upload_tags`,
`upload_shares`, `ingestion_jobs`, `validation_dataset_results` dùng
`upload_id` (VARCHAR) làm FK, không phải `id` (UUID).
Khai báo đúng `referencedColumnName = "upload_id"` trong `@JoinColumn`.

### 5. UploadMetadata – Composite PK
Dùng `@EmbeddedId` với class `UploadMetadataId` lồng bên trong.

### 6. JSONB fields
Tất cả field JSONB dùng `@Type(JsonBinaryType.class)` từ hypersistence-utils.
Map<String, Object> cho object, List<Map<String, Object>> cho array.

### 7. inet type (ip_address)
PostgreSQL `inet` không có type mapper sẵn trong Hibernate.
Ánh xạ về `String` + `columnDefinition = "inet"` là đủ cho hầu hết use case.
Nếu cần validate IP thực sự, dùng `InetAddress` + custom converter.
