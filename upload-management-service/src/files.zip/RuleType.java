package com.enterprise.upload.model.enums;

/**
 * Loại validation rule - ánh xạ từ PostgreSQL custom type {@code upload_db.rule_type_enum}.
 */
public enum RuleType {
    // Structural
    COLUMN_EXISTS,
    COLUMN_TYPE,
    ROW_COUNT_MIN,
    ROW_COUNT_MAX,
    // Completeness
    NOT_NULL,
    NOT_EMPTY,
    MAX_NULL_PERCENT,
    // Uniqueness
    UNIQUE,
    UNIQUE_COMPOSITE,
    // Format / Pattern
    REGEX_MATCH,
    DATE_FORMAT,
    ALLOWED_VALUES,
    EMAIL_FORMAT,
    PHONE_FORMAT,
    TAX_CODE_FORMAT,
    ACCOUNT_NUMBER_FORMAT,
    // Range / Boundary
    RANGE_MIN,
    RANGE_MAX,
    RANGE_BETWEEN,
    DATE_RANGE,
    DATE_NOT_FUTURE,
    DATE_NOT_PAST,
    // Referential
    FOREIGN_KEY,
    CROSS_TABLE_SUM,
    // Custom
    CUSTOM_SQL,
    CUSTOM_PYTHON
}
